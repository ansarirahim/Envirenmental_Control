/*******************************************************************************/
/* File Name:         uart.c                                                   */
/* Description:       uart communication                                       */
/* Author:            V. Kansal                                                */
/* Date:              25/08/2019                                               */
/* Language:          ANSI C / Compiler-dependent                              */
/* Supported Micro:   Independent                                              */
/************************************** (C) Copyright 2019 XXXXXXXXXX **********/
/*______ I N C L U D E - F I L E S ___________________________________________ */
#include "uart.h"
#include "string.h"
#include "modbusSlave.h"
#include "main.h"
#include "usart.h"
/*______ L O C A L - D E F I N E S____________________________________________*/
#define UART_TASK_PERIOD			((uint32_t)(1000/LOOP_TIME))  /* 100 ms*/
#define RX_BUF_SIZE 	10
#define TX_BUF_SIZE	    20
/*______ L O C A L - M A C R O S__ ___________________________________________*/

/*______ L O C A L - T Y P E S _______________________________________________*/

/*______ G L O B A L - D A T A _______________________________________________*/
extern DMA_HandleTypeDef hdma_usart1_rx;
/*______ P R I V A T E - D A T A _____________________________________________*/
uint8_t RxData[RX_BUF_SIZE];
uint8_t TxData[TX_BUF_SIZE];
/*______ I M P O R T - F U N C T I O N S - P R O T O T Y P E S _______________*/

/*______ L O C A L - F U N C T I O N S - P R O T O T Y P E S _________________*/
static void Uart_StartUartReception(void);
/*______ G L O B A L - F U N C T I O N S _____________________________________*/
/******************************************************************************/
/* Name:  HAL_UART_ErrorCallback                                              */
/* Role:                                                                      */
/* Interface:                                                                 */
/* Pre-condition:                                                             */
/* Constraints:                                                               */
/* Behaviour :                                                                */
/* DO                                                                         */
/*  [ ]                                                                       */
/* OD                                                                         */
/******************************************************************************/
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    __HAL_UART_CLEAR_IT(huart, UART_CLEAR_OREF);
    huart->ErrorCode |= HAL_UART_ERROR_ORE;
    if (huart->Instance == USART1)
    {
    	Uart_StartUartReception();
    }
}
/******************************************************************************/
/* Name:  HAL_UARTEx_RxEventCallback                                          */
/* Role:                                                                      */
/* Interface:                                                                 */
/* Pre-condition:                                                             */
/* Constraints:                                                               */
/* Behaviour :                                                                */
/* DO                                                                         */
/*  [ ]                                                                       */
/* OD                                                                         */
/******************************************************************************/
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if (huart->Instance == USART1)
	{
		if (RxData[0] == SLAVE_ID)
		{
			switch (RxData[1]){
			case 0x03:
				//readHoldingRegs();
				break;
			case 0x04:
				//readInputRegs();
				break;
			default:
				break;
			}
		}
	}
	Uart_StartUartReception();
}
/******************************************************************************/
/* Name:  HAL_UARTEx_RxEventCallback                                          */
/* Role:                                                                      */
/* Interface:                                                                 */
/* Pre-condition:                                                             */
/* Constraints:                                                               */
/* Behaviour :                                                                */
/* DO                                                                         */
/*  [ ]                                                                       */
/* OD                                                                         */
/******************************************************************************/
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	if (huart->Instance == USART1)
	{
		HAL_GPIO_WritePin(TX_EN_GPIO_Port,TX_EN_Pin, GPIO_PIN_RESET);
	}
}
/******************************************************************************/
/* Name:  UART_Init     		                                              */
/* Role:                                                                      */
/* Interface:                                                                 */
/* Pre-condition:                                                             */
/* Constraints:                                                               */
/* Behaviour :                                                                */
/* DO                                                                         */
/*  [ ]                                                                       */
/* OD                                                                         */
/******************************************************************************/
void UART_Init(void)
{
	HAL_GPIO_WritePin(TX_EN_GPIO_Port,TX_EN_Pin, GPIO_PIN_RESET);
	Uart_StartUartReception();
}
/******************************************************************************/
/* Name:  UART_Main     		                                              */
/* Role:                                                                      */
/* Interface:                                                                 */
/* Pre-condition:                                                             */
/* Constraints:                                                               */
/* Behaviour :                                                                */
/* DO                                                                         */
/*  [ ]                                                                       */
/* OD                                                                         */
/******************************************************************************/
void UART_Main(void)
{

}
/******************************************************************************/
/* Name:  UART_Send				                                              */
/* Role:                                                                      */
/* Interface:                                                                 */
/* Pre-condition:                                                             */
/* Constraints:                                                               */
/* Behaviour :                                                                */
/* DO                                                                         */
/*  [ ]                                                                       */
/* OD                                                                         */
/******************************************************************************/
void UART_Send(uint8_t* data, uint8_t size)
{HAL_Delay(1000);
	HAL_GPIO_WritePin(TX_EN_GPIO_Port,TX_EN_Pin, GPIO_PIN_SET);
	HAL_Delay(100);
	HAL_UART_Transmit_IT(&huart1,data,size);
	HAL_Delay(100);
	HAL_GPIO_WritePin(GPIOA,TX_EN_Pin, GPIO_PIN_RESET);
	HAL_Delay(100);
}
void UART_Send_Char(char c) {
    // Transmit one character through UART
    HAL_UART_Transmit_IT(&huart1, (uint8_t*)&c, 1);
}

void UART_Send_Text(char *s) {
    // Loop through the string until the null character is encountered
    while (*s != '\0') {
        // Send each character through UART
        UART_Send_Char(*s);
        s++; // Move to the next character in the string
    }
}
/*__________________ L O C A L - F U N C T I O N S____________________________*/
/******************************************************************************/
/* Name:  Uart_StartReception			                                      */
/* Role:                                                                      */
/* Interface:                                                                 */
/* Pre-condition:                                                             */
/* Constraints:                                                               */
/* Behaviour :                                                                */
/* DO                                                                         */
/*  [ ]                                                                       */
/* OD                                                                         */
/******************************************************************************/
static void Uart_StartUartReception(void)
{
	/* start the DMA again */
	HAL_GPIO_WritePin(TX_EN_GPIO_Port,TX_EN_Pin, GPIO_PIN_RESET);
	HAL_UARTEx_ReceiveToIdle_IT(&huart1, (uint8_t *) RxData, RX_BUF_SIZE);
	//__HAL_DMA_DISABLE_IT(&hdma_usart1_rx, DMA_IT_HT);
}
/*_____________________________END OF FILE: uart.c___________________________*/
