/*
 * uart.h
 *
 *  Created on: Mar 21, 2021
 *      Author: vinay.kansal
 */

#ifndef INC_UART_H_
#define INC_UART_H_

#include "main.h"

#define TX_OK   0
#define TX_ERROR 1

#define UART_PKT_START   		0xFD
#define UART_PKT_STOP			0xFE

extern void UART_Init(void);
extern void UART_Main(void);
extern uint8_t UART_Receive(uint8_t *buff);
extern void UART_Send(uint8_t* data, uint8_t size);
extern void UART_Send_Text(char *s);
/******************************************************************************/
/* Name:  UART_ReInit     		                                              */
/* Role:                                                                      */
/* Interface:                                                                 */
/* Pre-condition:                                                             */
/* Constraints:                                                               */
/* Behaviour :                                                                */
/* DO                                                                         */
/*  [ ]                                                                       */
/* OD                                                                         */
/******************************************************************************/
extern void UART_ReInit(void);

#endif /* INC_UART_H_ */
