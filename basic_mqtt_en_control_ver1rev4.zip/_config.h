#include <Arduino.h> 

/* BOARD INFO */
String DEVICE_NAME      = "Green"; 

/* WIFI INFO */ 
String WIFI_SSID        = "Airtel_seem_2877";
String WIFI_PASSWORD    = "air44055";

/* MQTT INFO */ 
String MQTT_HOST        = "3.110.187.253";
String MQTT_USERNAME    = "";
String MQTT_PASSWORD    = "";
String MQTT_CLIENT_ID   = "";
String MQTT_PREFIX      = "Mashroom/";

int    MQTT_PORT        = 1883;
int PUBLISH_EVERY       = 15L * 1000;
int MQTT_CONNECT_TIMEOUT= 10; 
