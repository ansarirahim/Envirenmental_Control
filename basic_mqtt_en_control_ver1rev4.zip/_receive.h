#include <Arduino.h>
#include <MqttConnector.h>
void parseAndUpdatePreset(const char* input);
extern MqttConnector* mqtt;

extern String MQTT_CLIENT_ID;
extern String MQTT_PREFIX;

extern int relayPin;
extern int relayPinState;
extern char Environment_Data[];

extern int LED_PIN;

void register_receive_hooks() {
  mqtt->on_subscribe([&](MQTT::Subscribe *sub) -> void {
    Serial.printf("Environment Data = %s \r\n", Environment_Data);
    sub->add_topic(MQTT_PREFIX);// + myName + "/$/+");
    sub->add_topic(MQTT_PREFIX + MQTT_CLIENT_ID + "/$/+");
  });

  mqtt->on_before_message_arrived_once([&](void) { });

 // mqtt->on_message([&](const MQTT::Publish & pub) { });
  mqtt->on_message([&](const MQTT::Publish &pub) {
  Serial.println("NEWReceived MQTT Message:");
  Serial.printf("NEWTopic: %s\n", pub.topic().c_str());
  Serial.printf("NEWPayload: %s\n", pub.payload_string().c_str());

  // You can add additional processing logic here if needed.

  // Call your existing message handling function
  //parseAndUpdatePreset(pub.payload_string().c_str());
});

  mqtt->on_after_message_arrived([&](String topic, String cmd, String payload) {
    Serial.printf("topic: %s\r\n", topic.c_str());
    Serial.printf("cmd: %s\r\n", cmd.c_str());
    Serial.printf("payload: %s\r\n", payload.c_str());
    if (cmd == "$/command") {
      parseAndUpdatePreset(payload.c_str());
      if (payload == "ON") {
        digitalWrite(relayPin, HIGH);
        digitalWrite(LED_PIN, LOW);
        relayPinState = HIGH;
      }
      else if (payload == "OFF") {
        digitalWrite(relayPin, LOW);
        digitalWrite(LED_PIN, HIGH);
        relayPinState = LOW;
      }
    }
    else if (cmd == "$/reboot") {
      ESP.restart();
    }
    else {
     Serial.println("command is not equal to $/command");
      
      // another message.
    }
  });
}

const char* UPDATE_PRESET = "UPDATE_PRESET_DATA";

// void parseAndUpdatePreset(const char* input) {
//   char keyword[strlen(UPDATE_PRESET) + 1];
//   int num1, num2, num3;

//   // Extract keyword and numeric values
//   int bytesRead = sscanf(input, "%s %d,%d,%d", keyword, &num1, &num2, &num3);

//   if (bytesRead == 4 && strcmp(keyword, UPDATE_PRESET) == 0) {
//     // Keyword matches and values are successfully read
//     // Now you can use num1, num2, and num3 for further processing
//     Serial.print("Keyword matched: ");
//     Serial.println(UPDATE_PRESET);
//     Serial.print("Num1: ");
//     Serial.println(num1);
//     Serial.print("Num2: ");
//     Serial.println(num2);
//     Serial.print("Num3: ");
//     Serial.println(num3);

//     // Perform actions based on the extracted values
//     // For example, update presets or perform some other operations
//   } else {
//     // Keyword doesn't match or incorrect format
//     Serial.println("Invalid input format or keyword");
//   }
// }

// Define the renamed buffers
bool mqttPresetUpdateCommand=false;
                                //5A A5 05 82 35 00 05 51
uint8_t presetTemp_mqtt[] =     {0x5a, 0xa5, 0x05, 0x82,0x25, 0x00, 0x00, 0x20};//,0};
uint8_t presetHumidity_mqtt[] = {0x5a, 0xa5, 0x05, 0x82, 0x30, 0x00, 0x0, 0x45};//,0};
uint8_t presetCo2_mqtt[] =      {0x5a, 0xa5, 0x05, 0x82, 0x35, 0x00, 0x04, 0x4};//,0};
#define MQTT_PRESET_TEMP_INDEX 0
#define MQTT_PRESET_HUM_INDEX 1
#define MQTT_PRESET_CO2_INDEX 2
extern void mqtt_updatePreset();
int presetThc[3];
#define MS_BYTE_INDEX 6
#define LS_BYTE_INDEX 7
void updateBuffers() {
  // Update presetTemp_mqtt
//5A A5 05 82 35 00 05 51
  presetTemp_mqtt[MS_BYTE_INDEX] = (presetThc[MQTT_PRESET_TEMP_INDEX] >> 8) & 0xFF;
  presetTemp_mqtt[LS_BYTE_INDEX] = presetThc[MQTT_PRESET_TEMP_INDEX] & 0xFF;

  // Update presetHumidity_mqtt
  presetHumidity_mqtt[MS_BYTE_INDEX] = (presetThc[MQTT_PRESET_HUM_INDEX] >> 8) & 0xFF;
  presetHumidity_mqtt[LS_BYTE_INDEX] = presetThc[MQTT_PRESET_HUM_INDEX] & 0xFF;

  // Update presetCo2_mqtt
  presetCo2_mqtt[MS_BYTE_INDEX] = (presetThc[MQTT_PRESET_CO2_INDEX] >> 8) & 0xFF;
  presetCo2_mqtt[LS_BYTE_INDEX] = presetThc[MQTT_PRESET_CO2_INDEX] & 0xFF;

// for(int i=0;i<8;i++)
//   Serial.printf("%.2X ", presetTemp_mqtt[i]);
//   Serial.write('\n');//

//   for(int i=0;i<8;i++)
//   Serial.printf("%.2X ", presetHumidity_mqtt[i]);
//   Serial.write('\n');//

//   for(int i=0;i<8;i++)
//   Serial.printf("%.2X ", presetCo2_mqtt[i]);
  Serial.write('\n');//
  mqtt_updatePreset();
}

void parseAndUpdatePreset(const char* input) {
  char keyword[strlen(UPDATE_PRESET) + 1];
  //int num1, num2, num3;
Serial.printf("\nOK-MQTT_Sub=%s",input);
  // Extract keyword and numeric values
  int bytesRead = sscanf(input, "%[^=]=%d,%d,%d", keyword, &presetThc[MQTT_PRESET_TEMP_INDEX], &presetThc[MQTT_PRESET_HUM_INDEX], &presetThc[MQTT_PRESET_CO2_INDEX]);

  if (bytesRead == 4 && strcmp(keyword, UPDATE_PRESET) == 0) {
    // Keyword matches and values are successfully read
    // Now you can use num1, num2, and num3 for further processing
    Serial.print("Keyword matched: ");
    Serial.println(UPDATE_PRESET);
    Serial.print("MQTT_PRESET_TEMP: ");
    Serial.println(presetThc[MQTT_PRESET_TEMP_INDEX]);
    Serial.print("MQTT_PRESET_HUM: ");
    Serial.println(presetThc[MQTT_PRESET_HUM_INDEX]);
    Serial.print("MQTT_PRESET_CO2: ");
    Serial.println(presetThc[MQTT_PRESET_CO2_INDEX]);
    updateBuffers();//
    mqttPresetUpdateCommand=true;

    // Perform actions based on the extracted values
    // For example, update presets or perform some other operations
  } else {
    // Keyword doesn't match or incorrect format
    Serial.println("Invalid input format or keyword");
  }
}