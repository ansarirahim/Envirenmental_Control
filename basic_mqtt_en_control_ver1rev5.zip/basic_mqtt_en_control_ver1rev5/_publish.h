#include <MqttConnector.h>
//#include "_config.h"
extern int relayPinState;
extern MqttConnector* mqtt;
extern void mqtt_updatePreset();
extern int relayPin;
extern int LED_PIN;
extern unsigned char buffer[];
extern char Environment_Data[];
#define MEASURED_CO2 0
#define MEASURED_TEMPERATURE 1
#define MEASURED_HUMIDITY 2
#define MEASURED_PRESET_CO2 3
#define MEASURED_PRESET_TEMPERATURE 4
#define MEASURED_PRESET_HUMIDITY 5

int enVariables[6];
#define TEMP_RELAY 7
#define CO2_RELAY 5
#define HUMIDITY_RELAY 4 
static void readEnvironment_Data(); 
void intArrayToCharArray(int* values, int numValues, char* charArray) {
  charArray[0] = '\0'; // Initialize the char array with an empty string
  
  for (int i = 0; i < numValues; i++) {
    char tempBuffer[10]; // Temporary buffer to store the string representation of the integer
    itoa(values[i], tempBuffer, 10); // Convert integer to string
    
    strcat(charArray, tempBuffer); // Concatenate the integer string to the char array
    
    if (i < numValues - 1) {
      strcat(charArray, ","); // Add a comma separator between values
    }
  }
}
// extern void updatePresetTempOnDisplay();
// extern void updatePresetCo2OnDisplay();
// extern void updatePresetHumOnDisplay();
extern String DEVICE_NAME;
extern int PUBLISH_EVERY;
extern int myVariables[];
#define FIRMWARE_VERSION "EN_CONTROL_VER1REV5"
// Function to create a comma-separated enBuffer from an array of index numbers
void createCSVBuffer(int* indices, int numIndices, char* outputBuffer, int bufferSize) {
  outputBuffer[0] = '\0'; // Initialize the enBuffer as an empty string

  for (int i = 0; i < numIndices; i++) {
    char temp[10]; // Temporary enBuffer to hold each index number as a string
    itoa(indices[i], temp, 10); // Convert index number to string
    strcat(outputBuffer, temp); // Concatenate the string to the enBuffer
    if (i < numIndices - 1) {
      strcat(outputBuffer, ","); // Add a comma if it's not the last value
    }
  }
}
#define MAX_BUFFER_SIZE 100
char enBuffer[MAX_BUFFER_SIZE];
void register_publish_hooks() {
  strcpy(Environment_Data, DEVICE_NAME.c_str());
  mqtt->on_prepare_data_once([&](void) {
    Serial.println("Initializing Environment_Data...");
  });

  mqtt->on_before_prepare_data([&](void) {
    readEnvironment_Data();//readSensor();
    createCSVBuffer(enVariables, 6, enBuffer, MAX_BUFFER_SIZE);
  });



  mqtt->on_prepare_data([&](JsonObject *root) {
    JsonObject& data = (*root)["d"];
    JsonObject& info = (*root)["info"];
    data["Firmware Version Revision"]=FIRMWARE_VERSION;
    //data["Environment Data"] =Environment_Data;//"Ansari.Raheem.Bhai.Zameer,Mohsin";//'Abdulraheem","AnsariRaheem";//enVariables;// myName;
    data["Environment Data"]=enBuffer;
    data["LIVE TEMP"]=enVariables[MEASURED_TEMPERATURE];
    data["LIVE HUMIDITY"]=enVariables[MEASURED_HUMIDITY];
    data["LIVE CO2"]=enVariables[MEASURED_CO2];
     data["PRESET TEMP"]=enVariables[MEASURED_PRESET_TEMPERATURE];
    data["PRESET HUMIDITY"]=enVariables[MEASURED_PRESET_HUMIDITY];
    data["PRESET CO2"]=enVariables[MEASURED_PRESET_CO2];
    data["millis"] = millis();
    //data["relayState"] = relayPinState;
    data["updateInterval"] = PUBLISH_EVERY;
  }, PUBLISH_EVERY);
  mqtt->on_after_prepare_data([&](JsonObject * root) {
    /**************
      JsonObject& data = (*root)["d"];
      data.remove("version");
      data.remove("subscription");
    **************/
  });

  mqtt->on_published([&](const MQTT::Publish & pub) {
      Serial.println("Published.");
  });
}
int len;

const byte HEADER_BYTE_1 = 0x5A;
const byte HEADER_BYTE_2 = 0xA5;
const byte MAX_PAYLOAD_LENGTH = 8;

enum State {
  WAITING_HEADER,
  RECEIVING_PAYLOAD
};

State state = WAITING_HEADER;
byte payload[MAX_PAYLOAD_LENGTH];
byte payloadIndex = 0;
byte payloadLength = 0;
extern bool mqttPresetUpdateCommand;
unsigned int humidity, co2, temperature, presetHumidity, presetCo2, presetTemperature;
void processPacket(unsigned char* uart_data, unsigned int data_length) {
  // int data_length = sizeof(uart_data);
  int i = 0;
  while (i < data_length) {
    if ((uart_data[i] == 0x5a) && (uart_data[i + 1] == 0xa5)) {
      switch (uart_data[i + 2]) {

        case 0x03:  //data length =3
          {
            if ((uart_data[i + 4] == 0x4F) && (uart_data[i + 4] == 0x4B))  //{A5}{03}{82}{4F}{4B}
              printf("Display responded");
            break;
          }
        case 0x05:  // Data Length = 5
          {
            switch (uart_data[i + 3]) {
              case 0x82:  // Command = Display Write
                {
                  switch (uart_data[i + 4]) {
                    case 0x20:  // co2
                      co2 = (((unsigned int)uart_data[i + 6]) << 8) | uart_data[i + 7];
                      enVariables[MEASURED_CO2]=co2;
                      printf("Measured Co2* = %u\n", co2);  //(((unsigned int)uart_data[i + 6]) << 8) | uart_data[i + 7]);
                      i += 7;
                      break;
                    case 0x10:  // Temperature
                      temperature = (((unsigned int)uart_data[i + 6]) << 8) | uart_data[i + 7];
                      enVariables[MEASURED_TEMPERATURE]=temperature;
                      printf("Measured Temperature* = %u\n", temperature);
                      i += 7;

                      break;
                    case 0x15:                                                                //humidity                                                      // CO2
                      humidity = (((unsigned int)uart_data[i + 6]) << 8) | uart_data[i + 7];  //
                      enVariables[MEASURED_HUMIDITY]=humidity;
                      printf("Measured Humidity* = %u\n", humidity);
                      i += 7;
                      break;
                    default:
                      break;
                  }
                  break;
                }
            }
            break;
          }
        case 0x06:  // Data Length = 6
          {
            switch (uart_data[i + 3]) {
              case 0x83:  // Command = Display Read
                {
                  switch (uart_data[i + 4]) {
                    case 0x25:  // Preset Temperature

                      presetTemperature = (((unsigned int)uart_data[i + 7]) << 8) | uart_data[i + 8];
                    enVariables[MEASURED_PRESET_TEMPERATURE]=presetTemperature;
                      if (temperature && presetTemperature) {
                        if (temperature > presetTemperature) {



                          digitalWrite(TEMP_RELAY, HIGH);

                          printf("TEMPERATURE RELAY IS ON\n");

                        } else {
                          printf("TEMPERATURE RELAY IS Off\n");
                          digitalWrite(TEMP_RELAY, LOW);
                        }
                        printf("Preset Temperature = %u\n", presetTemperature);  //
                      }
                      i += 8;

                      break;
                    case 0x30:  // Preset CO2
                      presetHumidity = (((unsigned int)uart_data[i + 7]) << 8) | uart_data[i + 8];
                      enVariables[MEASURED_PRESET_HUMIDITY]=presetHumidity;
                      
                      if (presetHumidity && humidity) {
                        printf("Preset Humidity = %u\n", presetHumidity);  //
                        if (humidity > presetHumidity) {

                          digitalWrite(HUMIDITY_RELAY, HIGH);

                          printf("Humidity RELAY IS ON\n");
                        } else {
                          printf("Humidity RELAY IS OFF\n");

                          digitalWrite(HUMIDITY_RELAY, LOW);
                        }
                      }
                      i += 8;
                      break;
                    case 0x35:      
                    if(mqttPresetUpdateCommand)
                    {
// updatePresetTempOnDisplay();//
// updatePresetHumOnDisplay();//
// updatePresetCo2OnDisplay();//
//mqtt_updatePreset();
mqttPresetUpdateCommand=false;
                    }
                                                                               // Preset Humidity
                      presetCo2 = (((unsigned int)uart_data[i + 7]) << 8) | uart_data[i + 8];  //
                      enVariables[MEASURED_PRESET_CO2]=presetCo2;

                      i += 8;
                      if (presetCo2 && co2) {
                        printf("Preset Co2 = %u\n", presetCo2);
                        if (co2 > presetCo2) {
                          printf("CO2 RELAY IS ON\n");

                          digitalWrite(CO2_RELAY, HIGH);

                        } else {
                          printf("CO2 RELAY IS Off\n");
                          digitalWrite(CO2_RELAY, LOW);
                        }
                      }
                      break;
                    default:
                      break;
                  }
                  break;
                }
            }
            break;
          }
        default:
          break;
      }
    }
    i++;
  }
}
//static void readSensor() {
  static void readEnvironment_Data(){
  // perform reading sensor 
  //Serial.println("Perform reading sensor...");
    len = Serial1.available();
  if (len)
  //Serial1.println(len);
  {
    Serial1.readBytes(buffer, len);
    processPacket(buffer, len);
    intArrayToCharArray(enVariables, 6, Environment_Data);
   
  }
}
